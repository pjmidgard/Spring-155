# Spring-155
Spring-155

Compression Quantum Python software

Algorithm Spring-155: Combinate all Division Repeat this many times. The number must be two n like this 2 ** n. E.g.: 32 bits 2 ** X+2+1 and plus also the same bits of long of the times: times (2**32)-1. 0-65535 bits and Times the same. Deep: X + 25 bits. 

Deep: 7

7+25=32 bits.

This Quantum program is for Quantum Supercomputers 4000 cubits.

How to use:
pip install qiskit
